package com.naveen.github_access_report.service;

import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;

@Service
public class GitHubService {
    public Map<String, Object> generateAccessReport() {
        Map<String, Object> report = new HashMap<>();
        report.put("alice", new String[]{"repo1 (admin)", "repo2 (read)"});
        report.put("bob", new String[]{"repo2 (write)", "repo3 (read)"});
        return report;
    }
}