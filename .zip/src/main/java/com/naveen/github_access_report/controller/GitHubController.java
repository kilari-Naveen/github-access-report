package com.naveen.github_access_report.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.naveen.github_access_report.service.GitHubService;
import java.util.Map;

@RestController
public class GitHubController {

    private final GitHubService gitHubService;

    // Constructor injection (preferred)
    public GitHubController(GitHubService gitHubService) {
        this.gitHubService = gitHubService;
    }

    // Correct endpoint mapping for assignment
    @GetMapping("/access-report")
    public Map<String, Object> getAccessReport() {
        return gitHubService.generateAccessReport();
    }
}
